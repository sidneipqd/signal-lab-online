"""
Motor inicial de análise de mercado (M1) — modo somente análise.
Este módulo NÃO envia ordens e NÃO garante rentabilidade.
Fonte de dados inicial: candles OHLCV via ccxt (ex.: mercado spot de cripto).
"""

from __future__ import annotations

import asyncio
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Any

import ccxt.async_support as ccxt
import pandas as pd


@dataclass
class Signal:
    ativo: str
    timeframe: str
    direcao: str
    estrategia: str
    horario: str
    preco_referencia: float
    ema9: float
    ema21: float
    rsi14: float
    justificativa: str


def calculate_rsi(series: pd.Series, period: int = 14) -> pd.Series:
    """Calcula RSI de forma padrão usando médias exponenciais de ganhos/perdas."""
    delta = series.diff()
    gains = delta.clip(lower=0)
    losses = -delta.clip(upper=0)
    avg_gain = gains.ewm(alpha=1 / period, min_periods=period, adjust=False).mean()
    avg_loss = losses.ewm(alpha=1 / period, min_periods=period, adjust=False).mean()
    rs = avg_gain / avg_loss.replace(0, 1e-12)
    rsi = 100 - (100 / (1 + rs))
    return rsi


def analyze_candles(df: pd.DataFrame, symbol: str, timeframe: str = "1m") -> dict[str, Any]:
    """
    Analisa candles fechados. Retorna COMPRA, VENDA ou SEM_SINAL.
    Regra demonstrativa:
      COMPRA: EMA9 cruza acima da EMA21 no candle fechado e RSI < 70.
      VENDA: EMA9 cruza abaixo da EMA21 no candle fechado e RSI > 30.
      Caso contrário: SEM_SINAL.
    Não é recomendação financeira; precisa ser validada com backtest.
    """
    required = {"timestamp", "open", "high", "low", "close", "volume"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Colunas ausentes: {', '.join(sorted(missing))}")
    if len(df) < 40:
        raise ValueError("São necessários pelo menos 40 candles para calcular os indicadores.")

    data = df.copy()
    data["ema9"] = data["close"].ewm(span=9, adjust=False).mean()
    data["ema21"] = data["close"].ewm(span=21, adjust=False).mean()
    data["rsi14"] = calculate_rsi(data["close"], 14)

    # Usa os dois últimos candles recebidos. O caller deve remover candles ainda abertos.
    prev = data.iloc[-2]
    last = data.iloc[-1]

    direction = "SEM_SINAL"
    reason = "Não houve cruzamento confirmado pelas regras configuradas."

    crossed_up = prev["ema9"] <= prev["ema21"] and last["ema9"] > last["ema21"]
    crossed_down = prev["ema9"] >= prev["ema21"] and last["ema9"] < last["ema21"]

    if crossed_up and last["rsi14"] < 70:
        direction = "COMPRA"
        reason = "EMA 9 cruzou acima da EMA 21; RSI abaixo de 70."
    elif crossed_down and last["rsi14"] > 30:
        direction = "VENDA"
        reason = "EMA 9 cruzou abaixo da EMA 21; RSI acima de 30."

    timestamp = last["timestamp"]
    if hasattr(timestamp, "to_pydatetime"):
        timestamp = timestamp.to_pydatetime()
    if isinstance(timestamp, (int, float)):
        timestamp = datetime.fromtimestamp(timestamp / 1000, tz=timezone.utc)
    if isinstance(timestamp, datetime):
        if timestamp.tzinfo is None:
            timestamp = timestamp.replace(tzinfo=timezone.utc)
        timestamp_str = timestamp.astimezone(timezone.utc).isoformat()
    else:
        timestamp_str = str(timestamp)

    def number(value: Any) -> float | None:
        return None if pd.isna(value) else round(float(value), 8)

    return asdict(Signal(
        ativo=symbol,
        timeframe=timeframe,
        direcao=direction,
        estrategia="EMA_CROSS_RSI14",
        horario=timestamp_str,
        preco_referencia=round(float(last["close"]), 8),
        ema9=number(last["ema9"]),
        ema21=number(last["ema21"]),
        rsi14=number(last["rsi14"]),
        justificativa=reason,
    ))


async def fetch_closed_candles(exchange: Any, symbol: str, timeframe: str = "1m", limit: int = 100) -> pd.DataFrame:
    """Busca candles e descarta o candle mais recente, que pode ainda estar aberto."""
    rows = await exchange.fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
    if len(rows) < 3:
        raise RuntimeError("A corretora retornou poucos candles.")
    df = pd.DataFrame(rows, columns=["timestamp", "open", "high", "low", "close", "volume"])
    # O último candle costuma estar em formação; removê-lo evita sinais intr candle.
    return df.iloc[:-1].reset_index(drop=True)


async def monitor(
    symbol: str = "BTC/USDT",
    timeframe: str = "1m",
    exchange_id: str = "binance",
    interval_seconds: int = 10,
) -> None:
    """Monitora mercado spot público. Não faz ordens nem acessa conta privada."""
    exchange_class = getattr(ccxt, exchange_id)
    exchange = exchange_class({"enableRateLimit": True})
    last_candle_timestamp = None

    try:
        print(f"Monitorando {symbol} ({timeframe}) via {exchange_id}. Ctrl+C para parar.")
        while True:
            df = await fetch_closed_candles(exchange, symbol, timeframe, limit=100)
            candle_timestamp = int(df.iloc[-1]["timestamp"])
            if candle_timestamp != last_candle_timestamp:
                result = analyze_candles(df, symbol, timeframe)
                print(result)
                last_candle_timestamp = candle_timestamp
            await asyncio.sleep(interval_seconds)
    finally:
        await exchange.close()


if __name__ == "__main__":
    try:
        asyncio.run(monitor())
    except KeyboardInterrupt:
        print("\nMonitor encerrado.")
