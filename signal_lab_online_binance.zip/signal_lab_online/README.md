# Signal Lab Online — Binance (modo demonstração)

## O que esta versão faz
- Consulta candles públicos da Binance Spot por meio de CCXT.
- Analisa BTC/USDT, ETH/USDT, SOL/USDT, BNB/USDT e XRP/USDT.
- Monitora continuamente usando o período configurado em `TIMEFRAME` (padrão 1m).
- Oferece análise manual em 1m, 5m ou 15m.
- Exibe sinais, indicadores e histórico em um painel web responsivo.
- Não envia ordens, não requer chave de API e não movimenta dinheiro.

## Executar localmente
Requer Python 3.11+.
1. Extraia o ZIP.
2. No terminal, entre na pasta e execute:
   `python -m venv .venv`
3. Ative o ambiente virtual e execute:
   `pip install -r requirements.txt`
4. Inicie a API:
   `uvicorn api:app --host 127.0.0.1 --port 8000`
5. Abra `index.html` no navegador.

Para desenvolvimento local, alguns navegadores podem bloquear chamadas de `file://` para a API. Se isso ocorrer, sirva o HTML com:
`python -m http.server 8080`
e abra `http://127.0.0.1:8080`.

## Hospedagem
O arquivo `render.yaml` é um ponto de partida para implantar a API em Render. O painel estático (`index.html`) pode ser hospedado em serviço de páginas estáticas. Se painel e API ficarem em domínios diferentes, abra o painel com `?api=https://URL-PUBLICA-DA-API` (sem barra final).

O arquivo `render.yaml` usa plano pago para evitar que um serviço durma, mas custos e disponibilidade mudam; revise o preço e as configurações antes de publicar. Não publique chaves secretas.

## Variáveis opcionais
- `SYMBOLS`: lista separada por vírgula, por exemplo `BTC/USDT,ETH/USDT,SOL/USDT`.
- `TIMEFRAME`: timeframe de monitoramento (1m, 5m ou 15m).
- `SCAN_SECONDS`: intervalo de varredura em segundos (mínimo 30; padrão 60).

## Limitações importantes
- Estratégia experimental baseada em regras técnicas simples; não é uma IA preditiva treinada.
- Sinais podem falhar; não há garantia de lucro.
- Histórico e cache ficam em memória e são perdidos se o processo reiniciar.
- Esta versão é somente Spot/read-only: sem execução automática de ordens.
- Para produção, configure CORS para os domínios reais, persistência do histórico, autenticação no painel, monitoramento de erros e testes de desempenho.
