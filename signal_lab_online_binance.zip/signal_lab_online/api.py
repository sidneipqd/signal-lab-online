from __future__ import annotations
import asyncio, os
from datetime import datetime, timezone
from typing import Any
import ccxt.async_support as ccxt
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from signal_engine import analyze_candles, fetch_closed_candles

SYMBOLS = [s.strip() for s in os.getenv("SYMBOLS", "BTC/USDT,ETH/USDT,SOL/USDT,BNB/USDT,XRP/USDT").split(",") if s.strip()]
TIMEFRAME = os.getenv("TIMEFRAME", "1m")
SCAN_SECONDS = max(30, int(os.getenv("SCAN_SECONDS", "60")))
app = FastAPI(title="Signal Lab API", version="0.2.0",
              description="Monitoramento de mercado cripto em modo demonstração; não envia ordens.")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=False,
                   allow_methods=["GET", "POST"], allow_headers=["*"])
exchange: Any = None
monitor_task: asyncio.Task | None = None
monitoring = False
signals: list[dict[str, Any]] = []
latest: dict[str, dict[str, Any]] = {}
lock = asyncio.Lock()

class AnalyzeRequest(BaseModel):
    ativo: str = Field(default="BTC/USDT")
    timeframe: str = Field(default=TIMEFRAME)

async def analyze_one(symbol: str, timeframe: str) -> dict[str, Any]:
    candles = await fetch_closed_candles(exchange, symbol, timeframe, limit=100)
    return analyze_candles(candles, symbol, timeframe)

async def record(result: dict[str, Any]) -> None:
    async with lock:
        latest[result["ativo"]] = result
        # Avoid duplicate history entries for the same closed candle and asset.
        key = (result.get("ativo"), result.get("timeframe"), result.get("horario"))
        if not any((x.get("ativo"), x.get("timeframe"), x.get("horario")) == key for x in signals):
            signals.insert(0, result)
            del signals[200:]

async def monitor_loop() -> None:
    global monitoring
    monitoring = True
    try:
        while monitoring:
            for symbol in SYMBOLS:
                if not monitoring:
                    break
                try:
                    await record(await analyze_one(symbol, TIMEFRAME))
                except Exception as exc:
                    # Keep monitoring other assets if one request fails.
                    print(f"[monitor] {symbol}: {type(exc).__name__}: {exc}", flush=True)
                await asyncio.sleep(0.25)
            if monitoring:
                await asyncio.sleep(SCAN_SECONDS)
    finally:
        monitoring = False

@app.on_event("startup")
async def startup():
    global exchange
    exchange = ccxt.binance({"enableRateLimit": True, "timeout": 15000})
    # Start in continuous monitoring mode on deployment.
    global monitor_task
    monitor_task = asyncio.create_task(monitor_loop())

@app.on_event("shutdown")
async def shutdown():
    global monitoring
    monitoring = False
    if monitor_task:
        monitor_task.cancel()
        try:
            await monitor_task
        except asyncio.CancelledError:
            pass
    if exchange:
        await exchange.close()

@app.get("/")
async def root():
    return {"status": "online", "service": "Signal Lab API", "mode": "demo/read-only"}

@app.get("/health")
async def health():
    return {"status": "ok", "horario": datetime.now(timezone.utc).isoformat()}

@app.get("/config")
async def config():
    return {"ativos": SYMBOLS, "timeframe_monitoramento": TIMEFRAME,
            "intervalo_varredura_segundos": SCAN_SECONDS, "monitorando": monitoring}

@app.post("/analisar")
async def analisar(payload: AnalyzeRequest):
    if payload.ativo not in SYMBOLS:
        raise HTTPException(400, f"Ativo não permitido nesta versão. Escolha: {', '.join(SYMBOLS)}")
    if payload.timeframe not in ("1m", "5m", "15m"):
        raise HTTPException(400, "Período permitido: 1m, 5m ou 15m.")
    try:
        result = await analyze_one(payload.ativo, payload.timeframe)
        await record(result)
        return {"ok": True, "sinal": result}
    except Exception as exc:
        raise HTTPException(502, f"Falha ao consultar a Binance: {type(exc).__name__}: {exc}") from exc

@app.get("/sinais")
async def get_signals():
    async with lock:
        return {"quantidade": len(signals), "sinais": signals}

@app.get("/ultimos")
async def get_latest():
    async with lock:
        return {"ativos": list(latest.values()), "quantidade": len(latest)}

@app.post("/monitor/iniciar")
async def start_monitor():
    global monitor_task
    if monitoring:
        return {"monitorando": True, "mensagem": "O monitoramento já está ativo."}
    monitor_task = asyncio.create_task(monitor_loop())
    return {"monitorando": True, "mensagem": "Monitoramento iniciado."}

@app.post("/monitor/pausar")
async def pause_monitor():
    global monitoring
    monitoring = False
    return {"monitorando": False, "mensagem": "Pausa solicitada; a tarefa encerrará o ciclo atual."}
